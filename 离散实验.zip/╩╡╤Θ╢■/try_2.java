package EX_1;

public class try_2 {
    public static void main(String[] args) {
        System.out.print("给定的集合上的二元关系如下：\n0 0 0 0\n1 0 0 0\n1 1 0 0\n1 1 1 0\n");
        int[][]a=new int[4][4];
        int i, j,p;
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                a[i][j]=0;
            }
        }
        a[2][0]=1;
        a[3][0]=1;
        a[1][0]=1;
        a[2][1]=1;
        a[3][1]=1;
        a[3][2]=1;
        int zifan,fanzifan,duicheng,fanduicheng,chuandi,Judge;
        zifan=0;
        fanzifan=0;
        duicheng=0;
        fanduicheng=0;
        chuandi=0;
        Judge=0;
        //判断自反性和反自反性
        for (i=0;i<4;i++){
            Judge=Judge+a[i][i];
        }
        if(Judge==0){
            fanzifan=1;
        }
        if (Judge==4){
            zifan=1;
        }
        //判断对称
        Judge=1;
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                if(a[i][j]!=a[j][i]){
                    Judge=0;
                }
            }
        }
        if(Judge==1){
            duicheng=1;
        }
        //判断反对称
        Judge=1;
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                if(i!=j&&a[i][j]==1&&a[i][j]==a[j][i]){
                   Judge=0;
                }
            }
        }
        if (Judge==1){
            fanduicheng=1;
        }
        //判断传递
        Judge=1;
        int [][]b=new int[4][4];
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                b[i][j]=0;
            }
        }
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                for(p=0;p<4;p++){
                    b[i][j]+=a[i][p]*a[p][j];
                }
                if(b[i][j]>0){
                    b[i][j]=1;
                }
                if(b[i][j]>a[i][j]){
                    Judge=0;
                }
            }
        }
        if (Judge==1) {
            chuandi = 1;
        }
        //传递闭包
        int []c=new int[100];
        int number,q;
        for(p=0;p<4;p++){
            number=0;
            q=0;
            for(j=0;j<4;j++){
                if (a[p][j]==1){
                    number+=1;
                    c[q]=j;
                    q++;
                }
            }
            for(i=0;i<4;i++){
                if(a[i][p]==1){
                    for (q=0;q<number;q++){
                        if(a[i][c[q]]==0){
                            a[i][c[q]]=1;
                        }
                    }
                }
            }
        }
        //输出结果
        System.out.print("自反性："+zifan+'\n');
        System.out.print("反自反性："+fanzifan+'\n');
        System.out.print("对称性："+duicheng+'\n');
        System.out.print("反对称性："+fanduicheng+'\n');
        System.out.print("传递性："+chuandi+'\n');
        System.out.print("传递闭包：\n");
        for (i=0;i<4;i++){
            for (j=0;j<4;j++){
                System.out.print(a[i][j]+" ");
            }
            System.out.print('\n');
        }
    }
}
