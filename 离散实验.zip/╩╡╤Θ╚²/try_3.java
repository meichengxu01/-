package EX_1;

public class try_3 {
    public static Boolean isZero(int[][] b,int m,int n){
        int i;
        int Sum;
        Sum=0;
        for (i=0;i<n;i++){
            Sum+=b[m][i];
        }
        if (Sum==0)
            return Boolean.TRUE;
        else
            return Boolean.FALSE;
    }
    public static Boolean isRepeat(int [][] b,int[] a,int m,int n,int j){
        int i;
        for (i=0;i<n;i++){
            if(b[m][i]!=0&&a[j]%b[m][i]==0){
                return Boolean.FALSE;
            }
        }
        return Boolean.TRUE;
    }
    public static int gongyingzi(int[] a,int i,int j){
        int p,Max,Min;
        if (a[i]>a[j]){
            Max=a[i];
            Min=a[j];
        }else {
            Max=a[j];
            Min=a[i];
        }
        p=Min;
        while (Boolean.TRUE){
            if(Max%p==0&&Min%p==0)
                break;
            p--;
        }
        return p;
    }
    public static int gongbeishu(int[] a,int i,int j){
        int p,Max,Min;
        if (a[i]>a[j]){
            Max=a[i];
            Min=a[j];
        }else {
            Max=a[j];
            Min=a[i];
        }
        p=Max;
        while (Boolean.TRUE){
            if(p%Max==0&&p%Min==0)
                break;
            p++;
        }
        return p;
    }
    public static void main(String[] args) {
        System.out.print("给定整数60，关系为整除关系\n60因子为：{ ");
        int i,number,j,q;
        number=0;
        int []a=new int[100];
        for (i=1;i<=60;i++){
            if (60%i==0){
                a[number]=i;
                System.out.print(i+" ");
                number++;
            }
        }
        System.out.print("}\n");
        //计算Cover的关系
        int [][]b=new int[number][number];
        for(i=0;i<number;i++){
            for (j=0;j<number;j++){
                b[i][j]=0;
            }
        }

        for (i=0;i<number;i++){
            q=0;
            for (j=i+1;j<number;j++){
                if (a[j]%a[i]==0){
                    if (isZero(b,i,number)){
                        b[i][q++]=a[j];
                    }else if (isRepeat(b,a,i,number,j)){
                        b[i][q++]=a[j];
                    }
                }
            }
        }
        System.out.print("覆盖关系为：“{");
        for(i=0;i<number;i++){
            for(j=0;j<number;j++){
                if (b[i][j]!=0){
                    System.out.print("<"+a[i]+","+b[i][j]+">"+" ");
                }
            }
        }
        System.out.print("}");
        //判断是否是有补格，即判断任意两个元素的公倍数和公因子为60和1
        int []check=new int[number];
        for (i=0;i<number;i++){
            check[i]=0;
        }
        for(i=0;i<number;i++){
            for(j=0;j<number;j++){
               if(i==j)
                   continue;
               if(gongyingzi(a,i,j)==1&&gongbeishu(a,i,j)==60){
                   check[i]=1;
               }
            }
        }
        for (i=0;i<number;i++){
            if (check[i]==0){
                System.out.print("\n不是有补格");
                break;
            }
        }
        if(i==number)
            System.out.print("是有补格");
    }
}
