﻿#include <iostream>
using namespace std;
int a[100], b[100], c[100];
int Result[100];
int n = 3;
void Experiment() {
	cout << "命题公式为：(¬PvQ)→R"
		int i = 0;
	for (int P = 0; P < 2; P++)
	{
		for (int Q = 0; Q < 2; Q++)
		{
			for (int R = 0; R < 2; R++)
			{
				a[i] = P;
				b[i] = Q;
				c[i] = R;
				Result[i] = (int(!P || Q) == int(R));
				cout << endl;
				i++;
				if (P == 0)
					cout << 'F' << '\t'; else cout << 'T' << '\t';
				if (Q == 0)
					cout << 'F' << '\t'; else cout << 'T' << '\t';
				if (R == 0)
					cout << 'F' << '\t'; else cout << 'T' << '\t';
				if (Result[i] == 0)
					cout << 'F' << '\t'; else cout << 'T' << '\t';

			}
		}
	}
}


//主合取范式
void zhuhequfanshi() {
	cout << endl << "主合取范式：";
	int number2 = 0;
	for (int i = 0; i < pow(2, n); i++) {
		if (Result[i] == 0) {  //值为真，输出相应真值的 P Q R
			if (a[i] == 0 && b[i] == 0 && c[i] == 0) {
				cout << "(PvQvR)";
				number2++;
			}
			else if (a[i] == 0 && b[i] == 0 && c[i] == 1) {
				cout << "(PvQv¬R)";
				number2++;
			}
			else if (a[i] == 0 && b[i] == 1 && c[i] == 0) {
				cout << "(Pv¬QvR)";
				number2++;
			}
			else if (a[i] == 0 && b[i] == 1 && c[i] == 1) {
				cout << "(Pv¬Qv¬R)";
				number2++;
			}
			else if (a[i] == 1 && b[i] == 0 && c[i] == 1) {
				cout << "(¬PvQv¬R)";
				number2++;
			}
			else if (a[i] == 1 && b[i] == 0 && c[i] == 0) {
				cout << "(¬PvQvR)";
				number2++;
			}
			else if (a[i] == 1 && b[i] == 1 && c[i] == 1) {
				cout << "(¬Pv¬Qv¬R)";
				number2++;
			}
			else if (a[i] == 1 && b[i] == 1 && c[i] == 0) {
				cout << "(¬Pv¬QvR)";
				number2++;
			}
			if (number2 != pow(2, n - 1))
				cout << " ⋀ ";
		}
	}
}

//主析取范式
void Zhuxiqufanshi() {
	int number = 0;

	cout << endl << "主析取范式：";

	for (int i = 0; i < pow(2, n); i++) {
		if (Result[i] == 1) {  //值为真，输出相应真值的 P Q R
			if (a[i] == 1 && b[i] == 1 && c[i] == 1) {
				cout << "(P⋀Q⋀R)";
				number++;
			}
			else if (a[i] == 1 && b[i] == 1 && c[i] == 0) {
				cout << "(P⋀Q⋀¬R)";
				number++;
			}
			else if (a[i] == 1 && b[i] == 0 && c[i] == 1) {
				cout << "(P⋀¬Q⋀R)";
				number++;
			}
			else if (a[i] == 1 && b[i] == 0 && c[i] == 0) {
				cout << "(P⋀¬Q⋀¬R)";
				number++;
			}
			else if (a[i] == 0 && b[i] == 1 && c[i] == 0) {
				cout << "(¬P⋀Q⋀¬R)";
				number++;
			}
			else if (a[i] == 0 && b[i] == 1 && c[i] == 1) {
				cout << "(¬P⋀Q⋀R)";
				number++;
			}
			else if (a[i] == 0 && b[i] == 0 && c[i] == 0) {
				cout << "(¬P⋀¬Q⋀¬R)";
				number++;
			}
			else if (a[i] == 0 && b[i] == 0 && c[i] == 1) {
				cout << "(¬P⋀¬Q⋀R)";
				number++;
			}
			if (number != pow(2, n - 1))
				cout << " V ";
		}
	}
}

int main()
{
	Experiment();
	zhuhequfanshi();
	Zhuxiqufanshi();
}