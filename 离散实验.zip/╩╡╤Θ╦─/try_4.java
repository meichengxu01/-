package EX_1;
import java.util.Scanner;
import java.util.Random;
public class try_4 {
    public static int m,n,s=0,t=0;
    public static int [][]a;//图的矩阵
    public static int[] path_1;//欧拉回路的路径
    public static int[] path_2;//欧拉路的路径
    public static void Fleury_1(int x){
        System.out.print("V"+x+" ");
        path_1[s++]=1;
        int count=0;
        int count2=0;
        for (int j=0;j<n;j++){
            if (a[x][j]==1){
                count=0;
                for(int i=0;i<n;i++){   //判断是否为割边
                    if(a[j][i]==1){
                        count++;
                    }
                }
                if (count==1){
                        continue;
                }else {
                    a[x][j]=0;
                    a[j][x]=0;
                    Fleury_1(j);
                }

            }
        }
        if(count==1){
            for(int i=0;i<n;i++){       //只剩割点的情况
                if (a[x][i]==1){
                    a[x][i]=0;
                    a[i][x]=0;
                    Fleury_1(i);
                }
            }
        }
        for (int i=0;i<m+1;i++){
            if (path_1[i]==1) {
                count2++;
            }
        }
        if(count2==m+1){      //结束语句
            return;
        }
    }
    public static void Fleury_2(int x){
        for(int i=0;i<n;i++){
            if (a[x][i]==1){
                a[x][i]=0;
                a[i][x]=0;
                Fleury_2(i);
            }
        }
        path_2[t++]=x;
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        m=0;
        n=0;
        while (Boolean.TRUE){           //判断输入的m，n是是否合理
            System.out.println("请输入n值：");
            n=scanner.nextInt();
            System.out.println("请输入m值：");
            m=scanner.nextInt();
            if(m>n*(n-1)/2||m<0||n<0){
                System.out.println("m不应该大于n*(n-1)/2\nm，n不应该为负数\n请重新输入");
                continue;
            }
            else{
                break;
            }
        }
        try_4.a=new int[n][n];
        Random random=new Random();
        int i,n_1,n_2,j;
        for (i=0;i<m;i++){          //m条边
            n_1=random.nextInt(n);//随机生成边
            n_2=random.nextInt(n);
            if(a[n_1][n_2]==0&&a[n_2][n_1]==0&&n_1!=n_2){      //判断对称
                a[n_1][n_2]=1;
                a[n_2][n_1]=1;
            }else {
                i=i-1;
            }
        }
        for (i=0;i<n;i++){
            System.out.print("[ ");
            for (j=0;j<n;j++){
                System.out.print(a[i][j]+" ");
            }
            System.out.print("]\n");
        }
        //通过可达性矩阵判断是否是连通图
        int[][]b=new int[n][n];//可达性矩阵
        for (i=0;i<n;i++){      //初始化矩阵
            for (j=0;j<n;j++){
                b[i][j]=a[i][j];
            }
        }
        int[] check=new int[100];//存储每行中值为1的元素的列数
        int p,number,q;
        for (p=0;p<n;p++){
            number=0;
            for(j=0;j<n;j++){
                if(b[p][j]==1){
                    check[number]=j; //存储列数
                    number++;          //每行元素为1的个数
                }
            }
            for(i=0;i<n;i++){
                for (q=0;q<number;q++){
                    if (b[i][p]==1&&b[i][check[q]]==0){
                        b[i][check[q]]=1;
                    }
                }
            }
        }
        int Judge=1;        //判断矩阵是否是连通的
        System.out.println("可达性矩阵：");
        for (i=0;i<n;i++){
            System.out.print("[ ");
            for (j=0;j<n;j++){
                System.out.print(b[i][j]+" ");
                if (b[i][j]==0)
                    Judge=0;
            }
            System.out.print("]\n");
        }
        if(Judge==0){
            System.out.println("不是连通的");
        }else
            System.out.println("是连通的");
        //计算结点度数
        int k=0;      //记录奇度数结点
        int[] dgree=new int[n];     //存储每个结点的度数
        int count=0;    //计算每个结点的度数
        int JI_count=0;     //计算度数为奇数的结点个数
        if (Judge==1){
            for(i=0;i<n;i++){
                count=0;
                for (j=0;j<n;j++){
                    if(a[i][j]==1){
                        count++;
                    }
                }
                dgree[i]=count;
                if (dgree[i]%2!=0){     //判断奇偶
                    k=i;
                    JI_count++;
                }
            }
            //初始化欧拉路径
            try_4.path_1=new int[m+1];
            for (i=0;i<m+1;i++){      //初始化欧拉回路
                 path_1[i]=m+1;
            }
            try_4.path_2=new int[m+1];
            for (i=0;i<m+1;i++){    //初始化欧拉路
                path_2[i]=m+1;
            }
            if(JI_count==0){
                System.out.println("所有结点的度都是偶数个，为欧拉图");
                System.out.print("欧拉回路为：");
                Fleury_1(0);
                System.out.print("\n");
            }
            else if(JI_count==2){
                System.out.println("有两个度数为奇数的结点，为半欧拉图");
                Fleury_2(k);
                System.out.println("欧拉路为：");
                for (i=0;i<m+1;i++){
                    System.out.print(" "+path_2[i]+" ");
                }
                System.out.print("\n");
            }else
                System.out.println("既不是欧拉图，也不是欧拉回路");

        }
    }
}
